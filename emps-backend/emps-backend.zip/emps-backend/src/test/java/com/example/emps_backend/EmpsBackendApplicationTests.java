package com.example.emps_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
