package com.example.emps_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpsBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpsBackendApplication.class, args);
	}

}
